#ifndef __NACHBOOL_H__
#define __NACHBOOL_H__   1

#define FALSE 0
#define TRUE 1

#endif 
