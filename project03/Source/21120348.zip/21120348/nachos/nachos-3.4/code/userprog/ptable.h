#ifndef PTABLE_H
#define PTABLE_H

#include "bitmap.h"
#include "pcb.h"

//#include "schandle.h"
#include "semaphore.h"

#define MAXPROCESS 10

class PTable {
	private:
		BitMap *bm;
		PCB *pcb[MAXPROCESS];
		int psize;
		Semaphore *bmsem;	// DUng de ngan chan truong hop nap 2 tien trinh cung mot luc
	
	public:
		PTable(int size);	
		~PTable();
		int ExecUpdate(char* name);	//SC_Exec
		int ExitUpdate(int);		//SC_Exit
		int JoinUpdate(int id);		//SC_Join
		int GetFreeSlot();
		bool IsExist(int pid);
		void Remove(int pid);

		char* GetFileName(int id);
};

#endif
