// pcb.h -> Process Control Block
// 	Save all information to control the process

#ifndef PCB_H
#define PCB_H

#include "thread.h"
#include "synch.h"

class PCB {
	private:
		Semaphore *joinsem; 	// Semaphore cho qua trinh join
		Semaphore *exitsem; 	// Semaphore cho qua trinh exit
		Semaphore * multex;  	// Semaphore cho qua trinh truy xuat doc quyen
		int exitcode;
		int pid;
		int numwait;	    	// So tien trinh da join
		char FileName[32];  	// Ten tien trinh
		Thread *thread;	    	// Tien trinh cua chuong trinh
	public:
		int parentID;	    	// ID cua tien trinh cha
		char boolBG;		// Kiem tra tien trinh nen

		PCB(int id);		// Constructor
		~PCB();			// Destructor

		int Exec(char *filename, int pid); 	// Nap chuong trinh co ten luu trong bien file name va processID se la pid

		int GetID() 
			{return pid;}	// Tra ve ProcessID cua tien trinh goi thuc hien
		int GetNumWait();	// Tra ve so luong tien trinh cho

		void JoinWait();	// Tien trinh cha doi tien trinh con ket thuc		
		void ExitWait();	// Tien trinh con ket thuc
		void JoinRelease();	// Bao cho tien trinh cha tiep tuc thuc thi
		void ExitRelease();	// Cho phep tien trinh con ket thuc
		void IncNumWait();	// Tang so tien trinh cho
		void DecNumWait();	// Giam so tien trinh cho
		void SetExitCode(int ec)// Dat exitcode cua tien trinh
			{exitcode = ec;}
		int GetExitCode() 	// Tra ve exitcode
			{return exitcode;}

		void SetFileName(char* filename);	// Dat ten tien trinh
		char* GetFileName(); 	// Tra ve ten tien trinh
};

#endif
