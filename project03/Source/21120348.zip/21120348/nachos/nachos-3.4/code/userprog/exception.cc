// exception.cc
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#include "filesys.h"

#define MAX_BUF_LEN 255
#define MAX_FILE_LEN 32

void IncreasePC()
{
	int pc = machine->ReadRegister(PCReg);
	machine->WriteRegister(PrevPCReg, pc);
	pc = machine->ReadRegister(NextPCReg);
	machine->WriteRegister(PCReg, pc);
	machine->WriteRegister(NextPCReg, pc + 4);
}

// Kernel - User system move function
char *User2System(int virtAddr, int limit)
{
	int i; // index
	int oneChar;
	char *kernelBuf = NULL;
	kernelBuf = new char[limit + 1]; // need for terminal string
	if (kernelBuf == NULL)
		return kernelBuf;
	memset(kernelBuf, 0, limit + 1);

	// printf("\n Filename u2s:");
	for (i = 0; i < limit; i++)
	{
		machine->ReadMem(virtAddr + i, 1, &oneChar);
		kernelBuf[i] = (char)oneChar;
		// printf("%c",kernelBuf[i]);
		if (oneChar == 0)
			break;
	}
	return kernelBuf;
}

int System2User(int virtAddr, int len, char *buffer)
{
	if (len < 0)
		return -1;
	if (len == 0)
		return len;
	int i = 0;
	int oneChar = 0;
	do
	{
		oneChar = (int)buffer[i];
		machine->WriteMem(virtAddr + i, 1, oneChar);
		i++;
	} while (i < len && oneChar != 0);
	machine->WriteRegister(2, 0);
	return i;
}

// Start of user-defined syscalls functions for better readability:

// Read an integer
void ex_ReadInt()
{
	char *buf = new char[MAX_BUF_LEN + 1];
	// Eliminate spaces in 2 ends:
	int left = 0;
	int right = synchcons->Read(buf, MAX_BUF_LEN) - 1; // bytes read - 1 = end index.

	while (buf[left] == ' ')
	{
		left++;
	}
	while (buf[right] == ' ')
	{
		right--;
	}

	bool hasMinus = (buf[left] == '-') ? true : false; // Minus sign is at the start.

	if (hasMinus)
		left++;

	int result = 0;

	// Scan the rest of buffer for legal input.
	for (int i = left; i <= right; i++)
	{
		if (buf[i] <= '9' && buf[i] >= '0')
		{
			result = result * 10 + buf[i] - 48; // Ascii to decimal.
		}
		else
		{
			delete[] buf;
			printf("\nInput is not an integer.\n");
			DEBUG('a', "\nInput is not an integer.\n");
			interrupt->Halt();
		}
	}
	delete[] buf;
	if (hasMinus)
		machine->WriteRegister(2, -result); // Return negative int
	else
		machine->WriteRegister(2, result); // Return positive int
}

void ex_PrintInt()
{
	int n = machine->ReadRegister(4);
	char *buf = new char[MAX_BUF_LEN + 1];
	// Int to string converter.

	bool isNeg = false;
	if (n < 0)
	{
		isNeg = true;
		n = -n;
	}

	int temp = n, len = 0;
	// find int length
	do
	{
		temp /= 10;
		len++;
	} while (temp != 0);
	// convert to char

	int start = 0;
	if (isNeg)
	{
		buf[0] = '-';
		len++;
		start++;
	}
	temp = len;
	// buf[len] = 0;
	while (start < temp--)
	{
		buf[temp] = (n % 10) + 48;
		n /= 10;
	}

	// synchcons writes to console
	synchcons->Write(buf, len);
	delete[] buf;
}

// Read a character.
void ex_ReadChar()
{
	char *buf = new char[MAX_BUF_LEN + 1];
	int numBytes = synchcons->Read(buf, MAX_BUF_LEN); // Read input into buffer;

	if (numBytes > 1) // buf has more than 1 character
	{
		printf("Only 1 character can be entered.\n");
		DEBUG('a', "Only 1 character can be entered.\n");
		machine->WriteRegister(2, 0);
	}
	else if (numBytes == 0) // buf has less than 1 character
	{
		printf("Empty.\n");
		DEBUG('a', "Empty.\n");
		machine->WriteRegister(2, 0);
	}
	else
	{
		char c = buf[0];
		machine->WriteRegister(2, c); // Successful input -> register syscall code
	}
	delete[] buf;
}

// Print a character.
void ex_PrintChar()
{
	// just print.
	char c = machine->ReadRegister(4);
	synchcons->Write(&c, 1);
}

void ex_ReadString()
{
	char *buf = NULL;
	int bufAddrUser;
	int length;

	bufAddrUser = machine->ReadRegister(4);
	length = machine->ReadRegister(5);

	buf = new char[length];
	memset(buf, 0, length);

	buf = User2System(bufAddrUser, length);
	synchcons->Read(buf, length);
	System2User(bufAddrUser, length, buf);

	delete[] buf;
}

void ex_PrintString()
{
	char *buf;
	int bufAddrUser;
	int length;

	bufAddrUser = machine->ReadRegister(4);
	buf = User2System(bufAddrUser, MAX_BUF_LEN + 1);
	length = 0;

	while (buf[length] != 0)
		length++;

	synchcons->Write(buf, length + 1);

	delete[] buf;
}

void ex_CreateFile()
{
	int addr;
	char *fileName;

	addr = machine->ReadRegister(4);

	fileName = User2System(addr, 255);

	// Error handling: if error occurs, return -1 to register 2.
	if (fileName == NULL)
	{
		printf("\nInsufficient memory");
		DEBUG('a', "\nInsufficient memory");
		machine->WriteRegister(2, -1);
		delete fileName;
		return;
	}

	if (strlen(fileName) == 0)
	{
		printf("\nFilename cannot be empty");
		DEBUG('a', "\nFilename cannot be empty");
		machine->WriteRegister(2, -1);
		delete fileName;
		return;
	}

	// Create file with size = 0
	// Dùng đối tượng fileSystem của lớp OpenFile để tạo file
	if (!fileSystem->Create(fileName, 0))
	{
		printf("\nError occured when creating file (%s)", fileName);
		machine->WriteRegister(2, -1);
		delete fileName;
		return;
	}

	machine->WriteRegister(2, 0);
	delete fileName;
}

// Exception for syscall Open(char* name, int type)
void ex_Open()
{
	int addr;
	int type;
	char *filename;

	addr = machine->ReadRegister(4);   // Get virtaddr of filename (char* name)
	filename = User2System(addr, 255); // Get para 1.

	type = machine->ReadRegister(5); // Get para 2: type (int type)

	int freeSlot = fileSystem->FindFreeSlot();

	if (freeSlot == -1)
	{
		machine->WriteRegister(2, -1); // Return not found.
		delete filename;
		return;
	}

	switch (type)
	{
	case 0:
		fileSystem->files[freeSlot] = fileSystem->Open(filename, type);
		if (fileSystem->files[freeSlot] != NULL)
		{
			machine->WriteRegister(2, freeSlot); // Return the found slot
		}
		break;
	case 1:
		fileSystem->files[freeSlot] = fileSystem->Open(filename, type);
		if (fileSystem->files[freeSlot] != NULL) // Mo file thanh cong
		{
			machine->WriteRegister(2, freeSlot); // trả về vị trí còn trống
		}
		break;
	case 2:
		machine->WriteRegister(2, 0);
		break;
	case 3:
		machine->WriteRegister(2, 1);
		break;
	}

	delete[] filename;
}

// Exception func for syscall Close
void ex_Close()
{
	int id;
	id = machine->ReadRegister(4);

	if (id >= 0 && id < 10)
	{
		if (fileSystem->files[id]) // not null
		{
			
			delete fileSystem->files[id];
			fileSystem->files[id] = NULL;
			machine->WriteRegister(2, 0); // SUCCESS!
			return;
		}
	}
	machine->WriteRegister(2, -1); // error
}

// Exception func for syscall Read - remember to use gSynchConsole
void ex_Read()
{
	int addr = machine->ReadRegister(4);
	int sz = machine->ReadRegister(5);
	int id = machine->ReadRegister(6);

	int start;
	int end;
	char *buf;

	if (id < 0 || id >= 10)
	{
		printf("\nFile ID is out of bounds. Reason: ID is %d", &id);
		DEBUG('a', "\nOut of Bounds.");
		machine->WriteRegister(2, -1);
		return;
	}

	if (fileSystem->files[id] == NULL)
	{
		printf("\nThis position is empty.");
		DEBUG('a', "\nEmpty file desc at designated position.");
		machine->WriteRegister(2, -1);
		return;
	}

	if (fileSystem->files[id]->type == 3) // attempt to read stdout
	{
		printf("\nCannot read stdout.");
		DEBUG('a', "\nCannot read stdout.");
		machine->WriteRegister(2, -1);
		return;
	}
	start = fileSystem->files[id]->CurPos();
	buf = User2System(addr, sz);
	if (fileSystem->files[id]->type == 2) // stdin
	{
		// the real number of bytes read
		int nB = synchcons->Read(buf, sz);
		System2User(addr, nB, buf);
		machine->WriteRegister(2, nB);
		delete buf;
		return;
	}

	
	
	

	

	if (fileSystem->files[id]->Read(buf, sz) > 0)
	{
		end = fileSystem->files[id]->CurPos();
		int nB = end - start;
		System2User(addr, nB, buf);
		machine->WriteRegister(2, nB);
		delete buf;
		return;
	}
	else {
		// if read cursor reaches EOF: return -2
		machine->WriteRegister(2, -2);
		delete buf;
	}
}

// syscall Write, vice versa with Read
void ex_Write()
{
	int addr = machine->ReadRegister(4);
	int sz = machine->ReadRegister(5);
	int id = machine->ReadRegister(6);

	int start;
	int end;
	char *buf;

	// out of bounds error
	if (id < 0 || id >= 10)
	{
		printf("\nFile ID is out of bounds. Reason: ID is %d", &id);
		DEBUG('a', "\nOut of Bounds.");
		machine->WriteRegister(2, -1);
		return;
	}

	// non-existent file
	if (fileSystem->files[id] == NULL)
	{
		printf("\nThis position is empty.");
		DEBUG('a', "\nEmpty file desc at designated position.");
		machine->WriteRegister(2, -1);
		return;
	}

	if (fileSystem->files[id]->type == 1 || fileSystem->files[id]->type == 2)
	{
		printf("\nCannot write to stdin or to read-only files.");
		DEBUG('a', "\nAttempt to write to read-only files.");
		machine->WriteRegister(2, -1);
		return;
	}

	start = fileSystem->files[id]->CurPos();
	buf = User2System(addr, sz);
	

	// Bytes read


	// Case of read/write files
	if (fileSystem->files[id]->type == 0)
	{
		if (fileSystem->files[id]->Write(buf, sz) > 0)
		{
			end = fileSystem->files[id]->CurPos();
			int nB = end - start;
			machine->WriteRegister(2, nB); // return bytes read
			delete buf;
			return;
		}
	}

	// Case of stdout file
	if (fileSystem->files[id]->type == 3)
	{
		int i = 0;
		while(buf[i] != 0 && buf[i] != '\n')
		{
			synchcons->Write(buf + i, 1);
			i++;
		}

		buf[i] = '\n';
		synchcons->Write(buf + i, 1);
		machine->WriteRegister(2, i - 1); // return bytes written
		delete buf;
		return;
	}
}

// void Exit(int exitCode);
void ex_Exit()
{
	int exitCode = machine->ReadRegister(4);

	if (exitCode != 0)
	{
		return;
	}

	int res = pTab->ExitUpdate(exitCode);
	currentThread->FreeSpace();
	currentThread->Finish();
	return;
}

// SpaceId Exec(char* name);
// name -> Ten cua file can chay tien trinh con
void ex_Exec()
{
	// Lay ten file
	int virtAddr;
	virtAddr = machine->ReadRegister(4);
	char *name;
	name = User2System(virtAddr, MAX_FILE_LEN + 1);

	// Bo nho khong du
	if (name == NULL)
	{
		DEBUG('a', "\n Not enough memory in System.\n");
		printf("\n Not enough memory in System.\n");
		return;
	}
	OpenFile *of = fileSystem->Open(name);
	// File khong ton tai
	if (of == NULL)
	{
		printf("\nExec:: Can't open this file.\n");
		machine->WriteRegister(2, -1);
		IncreasePC();
		return;
	}

	delete of;

	// Tra ve id cua tien trinh con
	int id = pTab->ExecUpdate(name);
	machine->WriteRegister(2, id);

	delete[] name;
	IncreasePC();

	return;
}

// int Join(SpaceID id)
// Nhap hai tien trinh dong thoi cung thuc hien -> Chi su dung cho da chuong
// Chua su dung cho Synchronize
void ex_Join()
{
	int id = machine->ReadRegister(4);
	int res = pTab->JoinUpdate(id);

	machine->WriteRegister(2, res);
	return;
}

// int CreateSemaphore(char* name, int semval);
// Tao Semaphore cho tien trinh va khoi tao gia tri Semaphore
void ex_CreateSemaphore()
{

	// Input
	int virtAddr = machine->ReadRegister(4);	// Dia chi ten tien trinh
	int semval = machine->ReadRegister(5);		// Gia tri semaphore khoi tao
	
	// Ten tien trinh
	char *name = User2System(virtAddr, MAX_FILE_LEN + 1);

	// Bo nho day
	if (name == NULL)
	{
		DEBUG('a', "\n Not enough memory in System.\n");
		printf("\n Not enough memory in System.\n");
		machine->WriteRegister(2, -1);
		delete[] name;
		return;
	}

	// Khoi tao tien trinh trong sTable
	int res = semTab->Create(name, semval);

	// Khong the khoi tao
	if (res == -1)
	{
		DEBUG('a', "\n Cannot Initiate Semaphore.\n");
		printf("\n Cannot Initiate Semaphore.\n");
		machine->WriteRegister(2, -1);
		delete[] name;
		return;
	}

	delete[] name;
	machine->WriteRegister(2, res);
	return;
}

// int Signal(char* name);
// Tien trinh co ten "name" -> Up()
void ex_Signal()
{
	// Lay ten cua tien trinh
	int virtAddr = machine->ReadRegister(4);
	char *name = User2System(virtAddr, MAX_FILE_LEN + 1);

	// Bo nho day
	if (name == NULL)
	{
		DEBUG('a', "\n Not enough memory in System.\n");
		printf("\n Not enough memory in System.\n");
		machine->WriteRegister(2, -1);
		delete[] name;
		return;
	}

	// Up()
	int res = semTab->Signal(name);

	// Khong tim thay Semaphore
	if (res == -1)
	{
		DEBUG('a', "\n This semaphore's name is not existed.\n");
		printf("\n This semaphore's name is not existed.\n");
		machine->WriteRegister(2, -1);
		delete[] name;
		return;
	}

	delete[] name;
	machine->WriteRegister(2, res);
	return;
}

// int Wait(char* name);
// Tien trinh co ten "name" -> Down()
void ex_Wait()
{
	// Lay ten tien trinh
	int virtAddr = machine->ReadRegister(4);
	char *name = User2System(virtAddr, MAX_FILE_LEN + 1);

	if (name == NULL)
	{
		DEBUG('a', "\n Not enough memory in System.\n");
		printf("\n Not enough memory in System.\n");
		machine->WriteRegister(2, -1);
		delete[] name;
		return;
	}
	
	// Down()
	int res = semTab->Wait(name);

	if (res == -1)
	{
		DEBUG('a', "\n This semaphore's name is not existed.\n");
		printf("\n This semaphore's name is not existed.\n");
		machine->WriteRegister(2, -1);
		delete[] name;
		return;
	}

	delete[] name;
	machine->WriteRegister(2, res);
	return;
}

void ex_Seek()
{
	// Di chuyen con tro den vi tri chi dinh trong file 
	int pos = machine->ReadRegister(4); // Vi tri can chuyen den trong file
	int id = machine->ReadRegister(5);	// Id cua file
	if (id < 0 || id > 10)
	{
		printf("\nCannot seek: Id out of file discription table.");
		machine->WriteRegister(2, -1);
		return;
	}

	// File khong ton tai
	if (fileSystem->files[id] == NULL)
	{
		printf("\nCannot seek: file not exist.");
		machine->WriteRegister(2, -1);
		return;
	}

	// Khong thuc hien voi cac file trong console
	if (id == 0 || id == 1)
	{
		printf("\nCannot seek: file in console.");
		machine->WriteRegister(2, -1);
		return;
	}
	// Neu pos = -1 -> pos = Length
	pos = (pos == -1) ? fileSystem->files[id]->Length() : pos;

	if (pos > fileSystem->files[id]->Length() || pos < 0) // Kiem tra lai vi tri pos co hop le khong
	{
		printf("\nCannot seek file to this position.");
		machine->WriteRegister(2, -1);
	}
	else
	{
		// Neu hop le thi tra ve vi tri di chuyen thuc su trong file
		// Tra ve vi tri da di chuyen den
		fileSystem->files[id]->Seek(pos);
		machine->WriteRegister(2, pos);
	}

	return;
}

// End...

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2.
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions
//	are in machine.h.
//----------------------------------------------------------------------

void ExceptionHandler(ExceptionType which)
{
	int type = machine->ReadRegister(2);

	switch (which)
	{
	case NoException:
		return;
		break;
	case PageFaultException:
		DEBUG('a', "The program will now exit due to exception: Page Fault\n");
		interrupt->Halt();
		break;
	case ReadOnlyException:
		DEBUG('a', "The program will now exit due to an attempt to write on Read-only files\n");
		interrupt->Halt();
		break;
	case BusErrorException:
		DEBUG('a', "The program will now exit due to error on bus\n");
		interrupt->Halt();
		break;
	case AddressErrorException:
		DEBUG('a', "The program will now exit due to address error\n");
		interrupt->Halt();
		break;
	case OverflowException:
		DEBUG('a', "The program will now exit due to overflow\n");
		interrupt->Halt();
		break;
	case IllegalInstrException:
		DEBUG('a', "The program will now exit due to illegal instruction\n");
		interrupt->Halt();
		break;
	case NumExceptionTypes:
		DEBUG('a', "The program will now exit due to exception: NumExceptionTypes\n");
		ASSERT(FALSE);
		interrupt->Halt();
		break;

	case SyscallException:
		switch (type)
		{
		case SC_Halt:
			DEBUG('a', "Shutdown, initiated by user program.\n");
			interrupt->Halt();
			break;

		case SC_ReadInt:
			ex_ReadInt();
			IncreasePC();
			break;

		case SC_PrintInt:
			ex_PrintInt();
			IncreasePC();
			break;

		case SC_ReadChar:
			ex_ReadChar();
			IncreasePC();
			break;

		case SC_PrintChar:
			ex_PrintChar();
			IncreasePC();
			break;

		case SC_ReadString:
			ex_ReadString();
			IncreasePC();
			break;

		case SC_PrintString:
			ex_PrintString();
			IncreasePC();
			break;

		// project 3 start here
		case SC_Create:
			ex_CreateFile();
			IncreasePC();
			break;

		case SC_Open:
			ex_Open();
			IncreasePC();
			break;

		case SC_Close:
			ex_Close();
			IncreasePC();
			break;

		case SC_Read:
			ex_Read();
			IncreasePC();
			break;

		case SC_Write:
			ex_Write();
			IncreasePC();
			break;

		case SC_Seek:
			ex_Seek();
			IncreasePC();
			break;

		// System calls for basic actions
		case SC_Exit:
			ex_Exit();
			IncreasePC();
			break;

		case SC_Exec:
			ex_Exec();
			break;

		case SC_Join:
			ex_Join();
			IncreasePC();
			break;

		// System calls for semaphore
		case SC_CreateSemaphore:
			ex_CreateSemaphore();
			IncreasePC();
			break;

		case SC_Signal: // Up
			ex_Signal();
			IncreasePC();
			break;

		case SC_Wait: // Down
			ex_Wait();
			IncreasePC();
			break;

		default:
			ASSERT(FALSE);
			interrupt->Halt();
			break;
		}
		break;
	default:
		printf("Unexpected user mode exception %d %d\n", which, type);
		ASSERT(FALSE);
		break;
	}
	/*
	if ((which == SyscallException) && (type == SC_Halt)) {
	DEBUG('a', "Shutdown, initiated by user program.\n");
	interrupt->Halt();
	} else {
	printf("Unexpected user mode exception %d %d\n", which, type);
	ASSERT(FALSE);
	}
	*/
}
