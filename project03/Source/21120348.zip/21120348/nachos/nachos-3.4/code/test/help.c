#include "syscall.h"
#include "copyright.h"

int main()
{
	PrintString("Nhom gom 5 thanh vien:\n");
	PrintString("21120279 - Le Tran Minh Khue\n");
	PrintString("21120289 - Diep Quoc Hoang Nam\n");
	PrintString("21120290 - Hoang Trung Nam\n");
	PrintString("21120348 - Nguyen Tran Trinh\n");
	PrintString("21120354 - Luong Thanh Tu\n");
	PrintString("Gioi thieu so chuong trinh:\n");
	PrintString("1. ascii: In ra bang ma ascii\n");
	PrintString("2. sort: Nhap n va so n phan tu cua mang,\n");
	PrintString("sap xep sau do in ra mang da sap xep\n");

	Halt();
}
