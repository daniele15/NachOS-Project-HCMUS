#include "syscall.h"
#include "copyright.h"

int main()
{
	char c[100];
	PrintString("Input String:\n");
	ReadString(c, 100);
	PrintString("Inputted String:\n");
	PrintString(c);
	PrintChar('\n');

	Halt();
}
