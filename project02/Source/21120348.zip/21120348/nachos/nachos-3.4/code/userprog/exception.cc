// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"

#define MAX_BUF_LEN 255


void IncreasePC()
{
	int pc = machine->ReadRegister(PCReg);
	machine->WriteRegister(PrevPCReg,pc);
	pc = machine->ReadRegister(NextPCReg);
	machine->WriteRegister(PCReg,pc);
	machine->WriteRegister(NextPCReg, pc + 4);
}

// Kernel - User system move function
char* User2System(int virtAddr,int limit) 
{ 
	int i;// index 
	int oneChar; 
	char* kernelBuf = NULL;  
	kernelBuf = new char[limit +1];//need for terminal string 
	if (kernelBuf == NULL) 
		return kernelBuf; 
 	memset(kernelBuf,0,limit+1); 
 
 	//printf("\n Filename u2s:"); 
 	for (i = 0 ; i < limit ;i++) 
 	{ 
 		machine->ReadMem(virtAddr+i,1,&oneChar); 
 		kernelBuf[i] = (char)oneChar; 
 		//printf("%c",kernelBuf[i]); 
 		if (oneChar == 0) 
 		break; 
		}
	return kernelBuf; 
}

int System2User(int virtAddr,int len,char* buffer) 
{ 
	if (len < 0) return -1; 
	if (len == 0)return len; 
	int i = 0; 
	int oneChar = 0 ; 
	do{ 
		oneChar= (int) buffer[i]; 
		machine->WriteMem(virtAddr+i,1,oneChar); 
		i ++; 
	}while(i < len && oneChar != 0); 
	machine->WriteRegister(2,0);
	return i;
}

// Start of user-defined syscalls functions for better readability:

// Read an integer
void ex_ReadInt() {
	char* buf = new char[MAX_BUF_LEN+1];
	// Eliminate spaces in 2 ends:
	int left = 0;
	int right = synchcons->Read(buf,MAX_BUF_LEN) - 1; // bytes read - 1 = end index.
	
	while (buf[left]==' '){
		left++;
	}
	while (buf[right]==' '){
		right--;
	}

	bool hasMinus = (buf[left]=='-')?true:false; // Minus sign is at the start.
	
	if (hasMinus) left++;

	int result = 0;
	
	// Scan the rest of buffer for legal input.
	for (int i = left;i<=right;i++){
		if (buf[i] <= '9' && buf[i] >= '0'){
			result = result*10 + buf[i] - 48; // Ascii to decimal.
		}
		else {
			delete[] buf;
			printf("\nInput is not an integer.\n");
			DEBUG('a',"\nInput is not an integer.\n");
			interrupt->Halt();
		}
	}
	delete[] buf;
	if (hasMinus) machine->WriteRegister(2,-result); // Return negative int
	else machine->WriteRegister(2,result); // Return positive int
}

void ex_PrintInt() {
	int n = machine->ReadRegister(4);
	char* buf = new char[MAX_BUF_LEN+1];
	// Int to string converter.

	bool isNeg = false;
	if (n<0) {
		isNeg = true;
		n=-n;
	}

	int temp = n, len = 0;
	// find int length
	do {
		temp/=10;
		len++;
	} while (temp != 0);
	// convert to char
	
	int start = 0;
	if (isNeg) {
		buf[0] = '-';
		len++;
		start++;
	}
	temp = len;
	//buf[len] = 0;
	while (start < temp--){
		buf[temp] = (n%10)+48;
		n/=10;
	}

	//synchcons writes to console
	synchcons->Write(buf,len);
	delete[]buf;
}

// Read a character.
void ex_ReadChar() {
	char* buf = new char[MAX_BUF_LEN+1];
	int numBytes = synchcons->Read(buf,MAX_BUF_LEN); //Read input into buffer;

	if (numBytes>1) // buf has more than 1 character
	{
		printf("Only 1 character can be entered.\n");
		DEBUG('a',"Only 1 character can be entered.\n");
		machine->WriteRegister(2,0);
	}
	else if (numBytes==0) // buf has less than 1 character
	{
		printf("Empty.\n");
		DEBUG('a',"Empty.\n");
		machine->WriteRegister(2,0);
	}
	else
	{
		char c = buf[0];
		machine->WriteRegister(2,c); //Successful input -> register syscall code
	}
	delete[] buf; 
}

// Print a character.
void ex_PrintChar() {
	// just print.
	char c = machine->ReadRegister(4);
	synchcons->Write(&c,1);
}

void ex_ReadString() {
	char *buf = NULL;
	int bufAddrUser;
	int length;

	bufAddrUser = machine->ReadRegister(4);
	length = machine->ReadRegister(5);

	buf = new char[length];
	memset(buf, 0, length);	
	
	buf = User2System(bufAddrUser, length);
	synchcons->Read(buf, length);
	System2User(bufAddrUser, length, buf);

	delete[] buf;
}

void ex_PrintString() {
	char* buf;
	int bufAddrUser;
	int length;

	bufAddrUser = machine->ReadRegister(4);
	buf = User2System(bufAddrUser, MAX_BUF_LEN+1);
	length = 0;

	while (buf[length] != 0) length++;

	synchcons->Write(buf, length + 1);

	delete[] buf;
}

// End...

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);

    switch(which)
    {
        case NoException:
		return;
		break;
	case PageFaultException:
		DEBUG('a', "The program will now exit due to exception: Page Fault\n");
		interrupt->Halt();
		break; 
	case ReadOnlyException:
		DEBUG('a', "The program will now exit due to an attempt to write on Read-only files\n");
		interrupt->Halt();
		break;
	case BusErrorException:
		DEBUG('a', "The program will now exit due to error on bus\n");
		interrupt->Halt();
		break;
	case AddressErrorException:
		DEBUG('a', "The program will now exit due to address error\n");
		interrupt->Halt();
		break;
	case OverflowException:
		DEBUG('a', "The program will now exit due to overflow\n");
		interrupt->Halt();
		break;
	case IllegalInstrException:
		DEBUG('a', "The program will now exit due to illegal instruction\n");
		interrupt->Halt();
		break;
	case NumExceptionTypes:
		DEBUG('a', "The program will now exit due to exception: NumExceptionTypes\n");
		ASSERT(FALSE);
		interrupt->Halt();
		break;
		
	case SyscallException:
		switch (type)
		{
			case SC_Halt:
				DEBUG('a', "Shutdown, initiated by user program.\n");
   				interrupt->Halt();
				break;

			case SC_ReadInt:
				ex_ReadInt();
				IncreasePC();
				break;

			case SC_PrintInt:
				ex_PrintInt();
				IncreasePC();
				break;

			case SC_ReadChar:
				ex_ReadChar();
				IncreasePC();
				break;

			case SC_PrintChar:
				ex_PrintChar();
				IncreasePC();
				break;

			case SC_ReadString:
				ex_ReadString();
				IncreasePC();
				break;

			case SC_PrintString:
				ex_PrintString();
				IncreasePC();
				break;

			default:
				ASSERT(FALSE);				
				interrupt->Halt();
				break;
		}
		break;
	default:
		printf("Unexpected user mode exception %d %d\n",which,type);
		ASSERT(FALSE);
		break;
    }
	/*    
	if ((which == SyscallException) && (type == SC_Halt)) {
	DEBUG('a', "Shutdown, initiated by user program.\n");
   	interrupt->Halt();
    } else {
	printf("Unexpected user mode exception %d %d\n", which, type);
	ASSERT(FALSE);
    }
	*/
}
