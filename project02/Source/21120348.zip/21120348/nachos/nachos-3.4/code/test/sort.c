#include "syscall.h"
#include "copyright.h"

main()
{
	int n = -1;
	int i, j;
	int tmp;
	int Arr[101];
	
	while (n < 0 || n > 100) {
		PrintString("Input size of Array: ");
		n = ReadInt();
	}

	for (i = 0; i < n;) {
		PrintString("Arr[");
		PrintInt(i);
		PrintString("] = ");
		Arr[i] = ReadInt();
		i = i + 1;
	}

	PrintString("Input Array:");
	for (i = 0; i < n; i++) {
		if (i % 10 == 0) {
			PrintChar('\n');
		}
		PrintInt(Arr[i]);
		PrintChar(' ');
	}
	PrintChar('\n');

	for (i = 0; i < n - 1; i++) {
		for (j = 0; j < n - i - 1; j++) {
			if (Arr[j] > Arr[j + 1]) {
				tmp = Arr[j];
				Arr[j] = Arr[j + 1];
				Arr[j + 1] = tmp;
			}
		}
	}

	PrintString("Sorted Array:");
	for (i = 0; i < n; i++) {
		if (i % 10 == 0) {
			PrintChar('\n');
		}
		PrintInt(Arr[i]);
		PrintChar(' ');
	}
	PrintChar('\n');

	Halt();
}
