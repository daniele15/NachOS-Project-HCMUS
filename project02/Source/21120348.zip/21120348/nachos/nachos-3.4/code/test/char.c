#include "syscall.h"
#include "copyright.h"

int main()
{
	char c;
	PrintString("Input Char: ");
	c = ReadChar();

	PrintString("Inputted Char: ");	
	PrintChar(c);
	PrintChar('\n');

	Halt();
}
