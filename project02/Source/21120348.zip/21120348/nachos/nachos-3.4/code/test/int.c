#include "syscall.h"
#include "copyright.h"

int main()
{
	int n;
	PrintString("Input Integer: ");
	n = ReadInt();
	PrintString("Inputted Integer: ");
	PrintInt(n);
	PrintChar('\n');

	Halt();
}
