#include "syscall.h"
#include "copyright.h"

int main()
{
	int i, j;
	PrintString("\n\t\tASCII Codes\n");
	PrintString("First 32 and last(DEL) are control code,\nso no need to print them.\n");
	for (i = 32; i < 127; i++) {
		if ((i - 32) % 6 == 0) PrintChar('\n');
		if (i < 100) PrintChar(' ');
		if (i < 10) PrintString("  ");
		PrintInt(i);
		PrintChar(':');
		PrintChar((char)i);
		PrintString("  ");
	}

	PrintChar('\n');
	Halt();
}
